/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22F%3A%5C%5CNextJS%5C%5Ccoffee-shop-near-me%5C%5Csrc%5C%5Capp%5C%5Ccomponents%5C%5Cbanner.tsx%22%2C%22ids%22%3A%5B%22default%22%5D%7D&server=false!":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22F%3A%5C%5CNextJS%5C%5Ccoffee-shop-near-me%5C%5Csrc%5C%5Capp%5C%5Ccomponents%5C%5Cbanner.tsx%22%2C%22ids%22%3A%5B%22default%22%5D%7D&server=false! ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/app/components/banner.tsx */ \"(app-pages-browser)/./src/app/components/banner.tsx\"));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtZmxpZ2h0LWNsaWVudC1lbnRyeS1sb2FkZXIuanM/bW9kdWxlcz0lN0IlMjJyZXF1ZXN0JTIyJTNBJTIyRiUzQSU1QyU1Q05leHRKUyU1QyU1Q2NvZmZlZS1zaG9wLW5lYXItbWUlNUMlNUNzcmMlNUMlNUNhcHAlNUMlNUNjb21wb25lbnRzJTVDJTVDYmFubmVyLnRzeCUyMiUyQyUyMmlkcyUyMiUzQSU1QiUyMmRlZmF1bHQlMjIlNUQlN0Qmc2VydmVyPWZhbHNlISIsIm1hcHBpbmdzIjoiQUFBQSx3TEFBbUkiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLz82OWE3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiLCB3ZWJwYWNrRXhwb3J0czogW1wiZGVmYXVsdFwiXSAqLyBcIkY6XFxcXE5leHRKU1xcXFxjb2ZmZWUtc2hvcC1uZWFyLW1lXFxcXHNyY1xcXFxhcHBcXFxcY29tcG9uZW50c1xcXFxiYW5uZXIudHN4XCIpO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%7B%22request%22%3A%22F%3A%5C%5CNextJS%5C%5Ccoffee-shop-near-me%5C%5Csrc%5C%5Capp%5C%5Ccomponents%5C%5Cbanner.tsx%22%2C%22ids%22%3A%5B%22default%22%5D%7D&server=false!\n"));

/***/ })

});