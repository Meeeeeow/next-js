const CoffeeStore = () => {
  return (
    <div>
      <h1>Coffee Store</h1>
    </div>
  );
};
export default CoffeeStore;
