const Hello = () => {
  return <div>Hello World from new route!</div>;
};

export default Hello;
