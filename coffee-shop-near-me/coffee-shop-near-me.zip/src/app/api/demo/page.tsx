const Demo = () => {
  return <div>Hello from new route!</div>;
};
export default Demo;
